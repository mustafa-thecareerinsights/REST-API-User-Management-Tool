import json
import requests

API_URL = "https://jsonplaceholder.typicode.com/users"
OUTPUT_FILE = "users_export.json"


def fetch_users():
    """Fetch user data from a public REST API."""
    try:
        response = requests.get(API_URL, timeout=10)
        response.raise_for_status()
        return response.json()

    except requests.exceptions.Timeout:
        print("Error: API request timed out. Please try again later.")
    except requests.exceptions.ConnectionError:
        print("Error: Unable to connect to the API. Check your internet connection.")
    except requests.exceptions.HTTPError as http_error:
        print(f"HTTP Error: {http_error}")
    except requests.exceptions.RequestException as error:
        print(f"API Error: {error}")
    except ValueError:
        print("Error: Could not read API response as JSON.")

    return []


def display_users(users):
    """Display users in a structured format."""
    if not users:
        print("No user data available.")
        return

    print("\nUser Information")
    print("-" * 90)
    print(f"{'ID':<5} {'Name':<25} {'Username':<18} {'Email':<30} {'City':<15}")
    print("-" * 90)

    for user in users:
        address = user.get("address", {})
        city = address.get("city", "N/A")

        print(
            f"{user.get('id', 'N/A'):<5} "
            f"{user.get('name', 'N/A'):<25} "
            f"{user.get('username', 'N/A'):<18} "
            f"{user.get('email', 'N/A'):<30} "
            f"{city:<15}"
        )


def search_users_by_name(users):
    """Search users by name."""
    if not users:
        print("No users available to search.")
        return

    search_name = input("Enter name to search: ").strip().lower()

    if not search_name:
        print("Search name cannot be empty.")
        return

    results = [
        user for user in users
        if search_name in user.get("name", "").lower()
    ]

    if results:
        print(f"\nSearch results for '{search_name}':")
        display_users(results)
    else:
        print(f"No users found with name containing '{search_name}'.")


def export_to_json(users):
    """Export user data to a JSON file."""
    if not users:
        print("No users available to export.")
        return

    try:
        with open(OUTPUT_FILE, "w", encoding="utf-8") as file:
            json.dump(users, file, indent=4)

        print(f"User data exported successfully to {OUTPUT_FILE}")

    except PermissionError:
        print("Error: Permission denied while writing JSON file.")
    except Exception as error:
        print(f"Error while exporting data: {error}")


def main():
    """Main program menu."""
    users = []

    while True:
        print("\nREST API User Management Tool")
        print("1. Fetch User Data")
        print("2. Display All Users")
        print("3. Search User by Name")
        print("4. Export Users to JSON File")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            users = fetch_users()
            if users:
                print(f"Successfully fetched {len(users)} users from API.")
            else:
                print("No users fetched.")

        elif choice == "2":
            display_users(users)

        elif choice == "3":
            search_users_by_name(users)

        elif choice == "4":
            export_to_json(users)

        elif choice == "5":
            print("Thank you for using REST API User Management Tool.")
            break

        else:
            print("Invalid choice. Please select a number from 1 to 5.")


if __name__ == "__main__":
    main()
