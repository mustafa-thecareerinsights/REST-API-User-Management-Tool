# REST API User Management Tool

## Objective
This Python application retrieves and manages user data from a public REST API.

## Public API Used
https://jsonplaceholder.typicode.com/users

## Features
- Fetch user data from a public REST API
- Display user information in a structured format
- Search users by name
- Export user data to a JSON file
- Proper API error handling
- Clean and simple menu-based Python application

## Requirements
Install the required package:

```bash
pip install requests
```

## How to Run

```bash
python app.py
```

## Menu Options

```text
1. Fetch User Data
2. Display All Users
3. Search User by Name
4. Export Users to JSON File
5. Exit
```

## Sample Output

```text
REST API User Management Tool
1. Fetch User Data
2. Display All Users
3. Search User by Name
4. Export Users to JSON File
5. Exit
Enter your choice (1-5): 1
Successfully fetched 10 users from API.
```

```text
User Information
------------------------------------------------------------------------------------------
ID    Name                      Username           Email                          City
------------------------------------------------------------------------------------------
1     Leanne Graham             Bret               Sincere@april.biz              Gwenborough
2     Ervin Howell              Antonette          Shanna@melissa.tv              Wisokyburgh
3     Clementine Bauch          Samantha           Nathan@yesenia.net             McKenziehaven
```

```text
Enter name to search: Leanne

Search results for 'leanne':

User Information
------------------------------------------------------------------------------------------
ID    Name                      Username           Email                          City
------------------------------------------------------------------------------------------
1     Leanne Graham             Bret               Sincere@april.biz              Gwenborough
```

```text
User data exported successfully to users_export.json
```

## Files Included
- app.py
- README.md
- sample_output.txt
- requirements.txt
- users_export.json

## Error Handling
The project handles API timeout, connection error, HTTP error, invalid API response, and file writing errors.
